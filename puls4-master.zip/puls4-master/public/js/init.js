window.Puls3 = {};

Puls3.Views = {};
Puls3.Collections = {};
Puls3.Models = {};
Puls3.Routers = {};

window.app = {};
window.routers = {};
window.plugs = {};
window.views = {};
window.collections = {};