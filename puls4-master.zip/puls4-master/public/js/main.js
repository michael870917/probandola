$(document).ready(function(){
	console.log('main.js loaded');
});
